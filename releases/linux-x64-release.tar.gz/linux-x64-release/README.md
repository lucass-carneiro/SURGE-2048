# How to play

Run the `surge` executable in this folder
